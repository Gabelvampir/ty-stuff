#
# bib2word: a BibTeX to Microsoft Word 2007 XML format converter
# Copyright 2010 Levente Hunyadi
#
# bib2word is part of tex2word.
#
# tex2word is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# tex2word is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

# Looks for BibTeX files in the current directory and parses them into an
# object hierarcy. This hierarchy can then be exported into external formats.

# Requires Python 3.0

import datetime
import os
import os.path
import re

def replaceall(text, replacementmap):
    for (search,replacement) in replacementmap.items():
        text = text.replace(search,replacement)
    return text

def htmlspecialchars(text):
    return replaceall(text.replace('&','&amp;'), {'<':'&lt;','>':'&gt;'})

#
# LaTeX accent dictionary
#

def swappair(pair):
    (left,right) = pair
    return (right,left)

def accentdictionary():
    """Imports accents that can be used in a LaTeX file."""
    
    with open('accents.txt', 'r', encoding='utf8') as f:
        return dict(map(swappair, [tuple(line.split('\t', 2)) for line in f.read().splitlines()]))

accentdict = accentdictionary()

def translateaccents(text):
    """Replaces all LaTeX accents in text with their Unicode equivalent."""
    
    return replaceall(text, accentdict)


#
# BibTeX data structures
#

class BibFields(dict):
    """Represents BibTeX key-value pairs.

    Examples include author={First Middle Last} or year={2008}.
    Regardless of their intuitive type (e.g. a year is an integer), values are
    stored as strings.
    """

    def __str__(self):
        l = ["%s = {%s}" % (key, value) for (key, value) in self.items()]
        return ",\n".join(l)

class BibEntry:
    """Represents a BibTeX entry.

    A BibTeX entry is identified by a unique BibTeX identifier, has a
    well-defined publication type (e.g. journal or inproceedings) and
    contains a list of key-value pairs.
    """

    entrytypes = frozenset([  # recognized entry types
        "comment",  # content ignored
        "article",
        "book",
        "booklet",
        "conference",
        "inbook",
        "incollection",
        "inproceedings",
        "manual",
        "mastersthesis",
        "misc",
        "phdthesis",
        "proceedings",
        "techreport",
        "unpublished"
    ])

    monthdict = {
        "jan": 1,
        "feb": 2,
        "mar": 3,
        "apr": 4,
        "may": 5,
        "jun": 6,
        "jul": 7,
        "aug": 8,
        "sep": 9,
        "oct": 10,
        "nov": 11,
        "dec": 12
    }

    def __init__(self, bibtype, bibid):
        self.bibtype = bibtype
        self.bibid = bibid
        self.fields = BibFields()

    def __str__(self):
        return r"""
@%(bibtype)s{%(bibid)s,
%(fields)s
}""" % vars(self)

    def tomonth(self):
        """The month of the publication if any."""

        if "month" in self.fields:
            m = self.fields["month"]
            m = m[0:3].lower();  # sufficient to look at first few characters
            if m in BibEntry.monthdict:
                return BibEntry.monthdict[m]
            else:
                return None

    def toyear(self):
        """The year of the publication if any."""

        if "year" in self.fields:
            return int(self.fields["year"], 10)
        else:
            return None

    def today(self):
        """The day of month of the publication if any."""

        if "day" in self.fields:
            daytext = self.fields["day"]
            mo = re.compile("(\d+)--?(\d+)").match(daytext)
            if mo:
                return int(mo.group(1), 10)
            else:
                return int(daytext, 10)
        else:
            return None

    def todate(self):
        """The date of the publication if any.

        An attempt is made to extract the information from the appropriate
        BibTeX fields.
        """

        year = self.toyear()
        month = self.tomonth()
        day = self.today()
        if year and month and day:
            return datetime.date(year, month, day)
        elif year and month:
            return datetime.date(year, month, 1)
        elif year:
            return datetime.date(year, 1, 1)
        else:
            return datetime.date.today()

    def isbetween(self, startdate, enddate):
        """True if the publication is dated between the specified dates."""

        return startdate <= self.todate() <= enddate

    def tolatexcite(self):
        """Convert the BibTeX entry into a LaTeX citation.

        Citations are needed to present only a selected subset of BibTeX
        entries in a LaTeX publication list.
        """

        return r"\nocite{%s}" % self.bibid

class BibSection:
    """Represents a collection of BibTeX entries.

    Related BibTeX entries are usually groupped into the same file. The caption
    for such a group is guessed based on the file name or the type of
    publications (e.g. journal or inproceedings) in the file.
    """

    defaultcaptions = {  # default captions for common file names
        # standard BibTeX namings
        "article" :       "Journal papers",
        "book" :          "Books",
        "booklet" :       "Books",
        "conference" :    "Conference papers",
        "inbook" :        "Book chapters",
        "incollection" :  "Book chapters",
        "inproceedings" : "Conference papers",
        "manual" :        "Manuals",
        "mastersthesis" : "Master's thesis",
        "misc" :          "Miscellaneous",
        "phdthesis" :     "PhD thesis",
        "proceedings" :   "Conference papers",
        "techreport" :    "Technical repoprts",
        "unpublished" :   "Miscellaneous",
        # alternative namings
        "journal" :       "Journal papers",
        "conferences" :   "Conference papers",
        "journals" :      "Journal papers",
        "techreports" :   "Technical reports",
        "miscellaneous" : "Miscellaneous"
    }

    def __init__(self, filename, entries):
        self.filename = filename
        if filename in BibSection.defaultcaptions:
            self.caption = BibSection.defaultcaptions[filename]
        else:
            self.caption = self.suggestcaption(filename)
        self.entries = entries

    def isempty(self):
        return len(self.entries) == 0

    def uniquetype(self):
        """Returns the unique type of BibTeX entries in the collection.

        None is returned if the group in not homogeneous.
        """

        entrytypeset = set([e.bibtype for e in self.entries])
        if len(entrytypeset) > 0:
            return entrytypeset.pop()
        else:
            return None

    def suggestcaption(self, default):
        """Returns a suggested caption for a collection of BibTeX entries.

        default is returned if the group in not homogeneous.
        """
        bibtype = self.uniquetype()
        if bibtype:
            return BibSection.defaultcaptions[bibtype]
        else:
            return default

    def filterbydate(self, startdate, enddate):
        """Keeps only entries between the specified dates."""

        self.entries = [e for e in self.entries if e.isbetween(startdate, enddate)]

    def sortbydate(self):
        """In-place sort by date."""

        self.entries.sort(key=BibEntry.todate,reverse=True)

    def tolatexsection(self):
        """Generates a LaTeX bibliography section."""

        return r"""
\renewcommand{\thebtauxfile}{%s}
\begin{btSect}{%s}
\section{%s}
\btPrintCited
\end{btSect}
""" % (self.filename, self.filename, self.caption)

    def tolatexcitation(self):
        """Generates a list of LaTeX citations."""

        return "\n".join([e.tolatexcite() for e in self.entries])

    def __str__(self):
        return "\n".join([str(entry) for entry in self.entries])

#
# BibTeX parser
#

def parsebib(filename):
    """Parses a file for BibTeX entries."""

    pattern = r"""
@(?P<type>[a-zA-Z0-9_]+) \s*
\{ \s* (?P<id>[-:a-zA-Z0-9_]+)  # BibTeX identifier
(?P<keysvalues>     # key = {value} pairs
    (?:
        \s* , \s*
        \w+ \s* = \s* (?:                        # key =
            \{ (?: [^{}] | \{ [^}]+ \} )* \} |   #   {value with some {escapes}}, no deeper nesting allowed
            "[^"]*"                              #   "value"
        )
    )*
)
\s* \}
"""
    subpattern = r"""
(?P<key>\w+) \s* = \s* (?P<value>    # key =
    { (?: [^{}]+ | { [^}]+ } )* } |  #   {value}
    "[^"]+"                          #   "value"
)
"""
    entries = []
    f = open(filename, "rU")
    try:
        contents = f.read()
        for mo in re.finditer(pattern, contents, re.MULTILINE | re.UNICODE | re.VERBOSE):
            entry = BibEntry(mo.group('type'), mo.group('id'))
            for smo in re.finditer(subpattern, mo.group('keysvalues'), re.MULTILINE | re.UNICODE | re.VERBOSE):
                entry.fields[smo.group('key')] = translateaccents(smo.group('value')[1:-1])
            entries.append(entry)
    finally:
        f.close()
    return entries

def parsedir():
    """Parses a directory for files with BibTeX entries."""

    bibsections = []
    for filename in os.listdir(os.getcwd()):
        if isbibfile(filename):
            entries = parsebib(filename)
            (name, extension) = os.path.splitext(filename)
            bibsections.append(BibSection(name, entries))
    return bibsections

def isbibfile(filename):
    """True if the file candidates as a BibTeX file."""

    (root, extension) = os.path.splitext(filename)
    return extension == '.bib'

wordbibtypemap = {'inproceedings':'ConferenceProceedings'}

def wordbib(bibsection):
    return r'<b:Sources SelectedStyle="\ISO690Nmerical.XSL" StyleName="ISO 690 - Numerical Reference" xmlns:b="http://schemas.openxmlformats.org/officeDocument/2006/bibliography" xmlns="http://schemas.openxmlformats.org/officeDocument/2006/bibliography">' + wordbibsection(bibsection) + '</b:Sources>'

def wordbibxml(name, contents):
    return '<b:' + name + '>' + contents + '</b:' + name + '>'

def wordbibsection(bibsection):
    return wordbibxml('Source', '\n'.join([wordbibentry(entry) for entry in bibsection.entries]))

def wordbibentry(bibentry):
    wordbibxml('Tag', bibentry.bibid)
    wordbibxml('SourceType', wordbibtypemap[bibentry.bibtype])
    wordbibxml('Guid', '{C2B96042-4288-4509-9AE8-E09B9D72C145}')
    wordbibxml('LCID', '0')
    wordbibxml('Author', '')  # Author -> Author -> NameList -> Person -> Last First and Author -> Editor -> NameList -> Person -> Last First
    wordbibxml('Title', bibentry.fields.get('title'))
    wordbibxml('Year', bibentry.fields.get('year'))
    wordbibxml('City', bibentry.fields.get('address'))
    wordbibxml('Publisher', bibentry.fields.get('publisher'))
    wordbibxml('StandardNumber', bibentry.fields.get())
    wordbibxml('Pages', bibentry.fields.get('pages'))
    wordbibxml('ConferenceName', bibentry.fields.get('booktitle'))
    wordbibxml('Volume', bibentry.fields.get('volume'))
    wordbibxml('ShortTitle', bibentry.fields.get())
    wordbibxml('Comments', bibentry.fields.get('note'))
    wordbibxml('RefOrder', '1')

#
# Program entry point
#

bibsections = parsedir()
for bibsection in bibsections:
    print(bibsection)
