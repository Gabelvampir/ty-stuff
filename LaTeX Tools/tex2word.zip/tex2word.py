#
# tex2word: a LaTeX to Microsoft Word 2007 XML format converter
# Copyright 2010 Levente Hunyadi
#
# tex2word is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# tex2word is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

import os
import os.path
import subprocess
import sys
import zipfile

# Prolog engine binary, configure as appropriate
if os.name == 'nt':
    paths = []
    if os.getenv('PROLOG_PATH') is not None:
        paths.append(os.getenv('PROLOG_PATH'))
    for programfolder in filter(None.__ne__, [os.getenv(variable) for variable in ['ProgramFiles','ProgramFiles(x86)']]):
        for subfolder in ['swipl','pl','prolog']:
            paths.append(os.path.join(programfolder, subfolder))
    prolog = next(os.path.join(p, 'bin', 'swipl.exe') for p in paths if os.path.exists(p))
else:
    prolog = 'swipl'

class Packager:
    """Packages source files into a single zipped package."""

    def __init__(self, basepath, packagename):
        self.archive = False  # create attribute for class
        (filename, extension) = os.path.splitext(packagename)
        if not extension:
            extension = '.docx'
        self.archive = zipfile.ZipFile(filename + extension, 'w', zipfile.ZIP_DEFLATED)
        self.archive.debug = 3
        self.basepath = basepath

    def add(self, relpath):
        fullpath = os.path.join(self.basepath, relpath)
        with open(fullpath, 'rb') as f:
            self.archive.writestr(relpath, f.read())

    def close(self):
        if self.archive:
            self.archive.close()

    def __del__(self):
        self.close()

def package(basepath, packagename):
    """Packages source files into a document."""

    packager = Packager(basepath, packagename)
    for (path, folders, files) in os.walk(basepath):
        for entry in files:
            fullpath = os.path.join(path, entry)
            relpath = os.path.relpath(fullpath, basepath)
            packager.add(relpath)
            print(relpath + ' added')
    packager.close()

def extract(path, packagename):
    """Extracts source files from a document."""

    archive = zipfile.ZipFile(packagename + '.docx', 'r')
    items = [item for item in archive.namelist() if not item.startswith( ('.','/') ) and not os.path.exists(os.path.join(path, packagename, item))]  # do not overwrite existing files
    archive.extractall(os.path.join(path, packagename), items)
    for item in items:
        print(item + ' extracted')

def main(arg):
    print("tex2word: a LaTeX to Microsoft Word 2007 XML format converter")
    print("Copyright 2010 Levente Hunyadi")
    print()
    if not os.path.exists(prolog):
        print('Prolog invocation error:\nProlog engine "{0}" not found.'.format(prolog))
    else:
        try:
            extract(os.getcwd(), 'skeleton')
            with open(arg, 'r', encoding='utf8') as f:  # check character encoding
                f.read()
            print('Calling Prolog engine to parse "{0}"...'.format(arg))
            args = [prolog, '-s', os.path.join(os.getcwd(), 'tex2word.pl'), '-g', "tex2word('{0}'), halt.".format(arg), '-t', 'halt(1).']
            p = subprocess.Popen(args, cwd=os.getcwd())
            p.wait()
            print()
            if p.returncode == 0:  # Prolog process terminated without error
                (filename, extension) = os.path.splitext(arg)
                docxfile = filename + '.docx'
                print('Packaging "{0}"...'.format(docxfile))
                package(os.path.join(os.getcwd(), 'skeleton'), docxfile)
                return
        except UnicodeDecodeError as err:
            print("Source file encoding error:\n{0}".format(err))
        except subprocess.CalledProcessError as err:
            print("Prolog invocation error:\n{0}".format(err))
        except IOError as err:
            print("Input/output error:\n{0}".format(err))
        except Exception as err:
            print("Unexpected error\n{0}: {1}".format(type(err), err))
    # input('Please check the error messages above. Press ENTER to exit...')

arg = 'sample.tex'
if len(sys.argv) >= 2:
    arg = sys.argv[1]
main(arg)
