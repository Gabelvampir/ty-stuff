%
% tex2word: a LaTeX to Microsoft Word 2007 XML format converter
% Copyright 2010 Levente Hunyadi
%
% tex2word is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% tex2word is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%

:- module(latexdb, [
	latex_special/3,    % DCG
	latex_character/3,  % DCG
	latex_accent/2,
	latex_operator/2,
	latex_symbol/2,
	latex_function/1
]).
:- encoding(utf8).

%
% LaTeX accented and special characters
%

latex_special(' ') --> "~", !.    % non-breaking space
latex_special('“') --> "``", !.   % left double quote
latex_special('”') --> "''", !.   % right double quote
latex_special('–') --> "--", !.   % en dash
latex_special('—') --> "---", !.  % em dash
latex_special('‘') --> "`", !.    % left single quote
latex_special('’') --> "'", !.    % right single quote

% LaTeX special characters
latex_character('€') --> "euro".
latex_character('…') --> "ldots".
latex_character('“') --> "textquotedblleft{}".   % left double quote
latex_character('”') --> "textquotedblright{}".  % right double quote

% LaTeX accented characters
latex_character('Á') --> "'A".
latex_character('á') --> "'a".
latex_character('Á') --> "'{A}".
latex_character('á') --> "'{a}".
latex_character('Ǽ') --> "'\\AE".
latex_character('ǽ') --> "'\\ae".
latex_character('Ǽ') --> "'{\\AE}".
latex_character('ǽ') --> "'{\\ae}".
latex_character('É') --> "'E".
latex_character('é') --> "'e".
latex_character('É') --> "'{E}".
latex_character('é') --> "'{e}".
latex_character('Í') --> "'I".
latex_character('í') --> "'i".
latex_character('Í') --> "'{I}".
latex_character('í') --> "'{i}".
latex_character('Ó') --> "'O".
latex_character('ó') --> "'o".
latex_character('Ó') --> "'{O}".
latex_character('ó') --> "'{o}".
latex_character('Ú') --> "'U".
latex_character('ú') --> "'u".
latex_character('Ú') --> "'{U}".
latex_character('ú') --> "'{u}".
latex_character('Ć') --> "'C".
latex_character('ć') --> "'c".
latex_character('Ć') --> "'{C}".
latex_character('ć') --> "'{c}".
latex_character('Ĺ') --> "'L".
latex_character('ĺ') --> "'l".
latex_character('Ĺ') --> "'{L}".
latex_character('ĺ') --> "'{l}".
latex_character('Ń') --> "'N".
latex_character('ń') --> "'n".
latex_character('Ń') --> "'{N}".
latex_character('ń') --> "'{n}".
latex_character('Ŕ') --> "'R".
latex_character('ŕ') --> "'r".
latex_character('Ŕ') --> "'{R}".
latex_character('ŕ') --> "'{r}".
latex_character('Ś') --> "'S".
latex_character('ś') --> "'s".
latex_character('Ś') --> "'{S}".
latex_character('ś') --> "'{s}".
latex_character('Ẃ') --> "'W".
latex_character('ẃ') --> "'w".
latex_character('Ẃ') --> "'{W}".
latex_character('ẃ') --> "'{w}".
latex_character('Ý') --> "'Y".
latex_character('ý') --> "'y".
latex_character('Ý') --> "'{Y}".
latex_character('ý') --> "'{y}".
latex_character('Ź') --> "'Z".
latex_character('ź') --> "'z".
latex_character('Ź') --> "'{Z}".
latex_character('ź') --> "'{z}".
latex_character('À') --> "`A".
latex_character('à') --> "`a".
latex_character('À') --> "`{A}".
latex_character('à') --> "`{a}".
latex_character('È') --> "`E".
latex_character('è') --> "`e".
latex_character('È') --> "`{E}".
latex_character('è') --> "`{e}".
latex_character('Ì') --> "`I".
latex_character('ì') --> "`i".
latex_character('Ì') --> "`{I}".
latex_character('ì') --> "`{i}".
latex_character('Ò') --> "`O".
latex_character('ò') --> "`o".
latex_character('Ò') --> "`{O}".
latex_character('ò') --> "`{o}".
latex_character('Ù') --> "`U".
latex_character('ù') --> "`u".
latex_character('Ù') --> "`{U}".
latex_character('ù') --> "`{u}".
latex_character('Ẃ') --> "'W".
latex_character('ẃ') --> "'w".
latex_character('Ẃ') --> "'{W}".
latex_character('ẃ') --> "'{w}".
latex_character('Ý') --> "'Y".
latex_character('ý') --> "'y".
latex_character('Ý') --> "'{Y}".
latex_character('ý') --> "'{y}".
latex_character('Â') --> "^A".
latex_character('â') --> "^a".
latex_character('Â') --> "^{A}".
latex_character('â') --> "^{a}".
latex_character('Ê') --> "^E".
latex_character('ê') --> "^e".
latex_character('Ê') --> "^{E}".
latex_character('ê') --> "^{e}".
latex_character('Î') --> "^I".
latex_character('î') --> "^i".
latex_character('Î') --> "^{I}".
latex_character('î') --> "^{i}".
latex_character('Ô') --> "^O".
latex_character('ô') --> "^o".
latex_character('Ô') --> "^{O}".
latex_character('ô') --> "^{o}".
latex_character('Û') --> "^U".
latex_character('û') --> "^u".
latex_character('Û') --> "^{U}".
latex_character('û') --> "^{u}".
latex_character('Ĉ') --> "^C".
latex_character('ĉ') --> "^c".
latex_character('Ĉ') --> "^{C}".
latex_character('ĉ') --> "^{c}".
latex_character('Ĝ') --> "^G".
latex_character('ĝ') --> "^g".
latex_character('Ĝ') --> "^{G}".
latex_character('ĝ') --> "^{g}".
latex_character('Ĥ') --> "^H".
latex_character('ĥ') --> "^h".
latex_character('Ĥ') --> "^{H}".
latex_character('ĥ') --> "^{h}".
latex_character('Ĵ') --> "^J".
latex_character('ĵ') --> "^j".
latex_character('Ĵ') --> "^{J}".
latex_character('ĵ') --> "^{j}".
latex_character('Ŝ') --> "^S".
latex_character('ŝ') --> "^s".
latex_character('Ŝ') --> "^{S}".
latex_character('ŝ') --> "^{s}".
latex_character('Ŵ') --> "^W".
latex_character('ŵ') --> "^w".
latex_character('Ŵ') --> "^{W}".
latex_character('ŵ') --> "^{w}".
latex_character('Ŷ') --> "^Y".
latex_character('ŷ') --> "^y".
latex_character('Ŷ') --> "^{Y}".
latex_character('ŷ') --> "^{y}".
latex_character('Ä') --> "\"A".
latex_character('ä') --> "\"a".
latex_character('Ä') --> "\"{A}".
latex_character('ä') --> "\"{a}".
latex_character('Ë') --> "\"E".
latex_character('ë') --> "\"e".
latex_character('Ë') --> "\"{E}".
latex_character('ë') --> "\"{e}".
latex_character('Ï') --> "\"I".
latex_character('ï') --> "\"i".
latex_character('Ï') --> "\"{I}".
latex_character('ï') --> "\"{i}".
latex_character('Ö') --> "\"O".
latex_character('ö') --> "\"o".
latex_character('Ö') --> "\"{O}".
latex_character('ö') --> "\"{o}".
latex_character('Ü') --> "\"U".
latex_character('ü') --> "\"u".
latex_character('Ü') --> "\"{U}".
latex_character('ü') --> "\"{u}".
latex_character('Ẅ') --> "\"W".
latex_character('ẅ') --> "\"w".
latex_character('Ẅ') --> "\"{W}".
latex_character('ẅ') --> "\"{w}".
latex_character('Ÿ') --> "\"Y".
latex_character('ÿ') --> "\"y".
latex_character('Ÿ') --> "\"{Y}".
latex_character('ÿ') --> "\"{y}".
latex_character('Ǎ') --> "v{A}".
latex_character('ǎ') --> "v{a}".
latex_character('Ě') --> "v{E}".
latex_character('ě') --> "v{e}".
latex_character('Ǐ') --> "v{I}".
latex_character('ǐ') --> "v{i}".
latex_character('Ǒ') --> "v{O}".
latex_character('ǒ') --> "v{o}".
latex_character('Ǔ') --> "v{U}".
latex_character('ǔ') --> "v{u}".
latex_character('Č') --> "v{C}".
latex_character('č') --> "v{c}".
latex_character('Ď') --> "v{D}".
latex_character('ď') --> "v{d}".
latex_character('Ľ') --> "v{L}".
latex_character('ľ') --> "v{l}".
latex_character('Ň') --> "v{N}".
latex_character('ň') --> "v{n}".
latex_character('Ř') --> "v{R}".
latex_character('ř') --> "v{r}".
latex_character('Š') --> "v{S}".
latex_character('š') --> "v{s}".
latex_character('Ť') --> "v{T}".
latex_character('ť') --> "v{t}".
latex_character('Ž') --> "v{Z}".
latex_character('ž') --> "v{z}".
latex_character('Ã') --> "~A".
latex_character('ã') --> "~a".
latex_character('Ã') --> "~{A}".
latex_character('ã') --> "~{a}".
latex_character('Ã') --> "~A".
latex_character('ã') --> "~a".
latex_character('Ã') --> "~{A}".
latex_character('ã') --> "~{a}".
latex_character('Ĩ') --> "~I".
latex_character('ĩ') --> "~i".
latex_character('Ĩ') --> "~{I}".
latex_character('ĩ') --> "~{i}".
latex_character('Õ') --> "~O".
latex_character('õ') --> "~o".
latex_character('Õ') --> "~{O}".
latex_character('õ') --> "~{o}".
latex_character('Ũ') --> "~U".
latex_character('ũ') --> "~u".
latex_character('Ũ') --> "~{U}".
latex_character('ũ') --> "~{u}".
latex_character('Ñ') --> "~N".
latex_character('ñ') --> "~n".
latex_character('Ñ') --> "~{N}".
latex_character('ñ') --> "~{n}".
latex_character('Ỹ') --> "~Y".
latex_character('ỹ') --> "~y".
latex_character('Ỹ') --> "~{Y}".
latex_character('ỹ') --> "~{y}".
latex_character('Ç') --> "c{C}".
latex_character('ç') --> "c{c}".
latex_character('Ģ') --> "c{G}".
latex_character('ģ') --> "c{g}".
latex_character('Ķ') --> "c{K}".
latex_character('ķ') --> "c{k}".
latex_character('Ļ') --> "c{L}".
latex_character('ļ') --> "c{l}".
latex_character('Ņ') --> "c{N}".
latex_character('ņ') --> "c{n}".
latex_character('Ŗ') --> "c{R}".
latex_character('ŗ') --> "c{r}".
latex_character('Ş') --> "c{S}".
latex_character('ş') --> "c{s}".
latex_character('Ţ') --> "c{T}".
latex_character('ţ') --> "c{t}".
latex_character('Ő') --> "H{O}".
latex_character('ő') --> "H{o}".
latex_character('Ű') --> "H{U}".
latex_character('ű') --> "H{u}".

%
% LaTeX special characters in math mode
%

% Accents
latex_accent(hat, "ˆ").
latex_accent(tilde, "̃").
latex_accent(bar, "̅").
latex_accent('Bar', "̿").
latex_accent(dot, "̇").
latex_accent(ddot, "̈").
latex_accent(overleftarrow, "⃖").
latex_accent(vec, "⃗").
latex_accent(overleftharpoon, "⃐").
latex_accent(overrightharpoon, "⃑").

% Operators
latex_operator(sum, "∑").
latex_operator(prod, "∏").
latex_operator(coprod, "∐").
latex_operator(int, "∫").
latex_operator(iint, "∬").
latex_operator(iiint, "∭").
latex_operator(oint, "∮").
latex_operator(oiint, "∯").
latex_operator(bigcup, "⋃").  % set union
latex_operator(bigcap, "⋂").  % set intersection

% Greek letters
latex_symbol('Alpha', "Α").
latex_symbol('Beta', "Β").
latex_symbol('Gamma', "Γ").
latex_symbol('Delta', "Δ").
latex_symbol('Epsilon', "Ε").
latex_symbol('Zeta', "Ζ").
latex_symbol('Eta', "Η").
latex_symbol('Theta', "Θ").
latex_symbol('Iota', "Ι").
latex_symbol('Kappa', "Κ").
latex_symbol('Lambda', "Λ").
latex_symbol('Mu', "Μ").
latex_symbol('Nu', "Ν").
latex_symbol('Xi', "Ξ").
latex_symbol('Omicron', "Ο").
latex_symbol('Pi', "Π").
latex_symbol('Rho', "Ρ").
latex_symbol('Sigma', "Σ").
latex_symbol('Tau', "Τ").
latex_symbol('Upsilon', "Υ").
latex_symbol('Phi', "Φ").
latex_symbol('Chi', "Χ").
latex_symbol('Psi', "Ψ").
latex_symbol('Omega', "Ω").
latex_symbol(alpha, "α").
latex_symbol(beta, "β").
latex_symbol(gamma, "γ").
latex_symbol(delta, "δ").
latex_symbol(varepsilon, "ε").
latex_symbol(epsilon, "ϵ").
latex_symbol(zeta, "ζ").
latex_symbol(eta, "η").
latex_symbol(theta, "θ").
latex_symbol(vartheta, "ϑ").
latex_symbol(iota, "ι").
latex_symbol(kappa, "κ").
latex_symbol(lambda, "λ").
latex_symbol(mu, "μ").
latex_symbol(nu, "ν").
latex_symbol(xi, "ξ").
latex_symbol(omicron, "ο").
latex_symbol(pi, "π").
latex_symbol(varpi, "ϖ").
latex_symbol(rho, "ρ").
latex_symbol(varrho, "ϱ").
latex_symbol(sigma, "σ").
latex_symbol(varsigma, "ς").
latex_symbol(tau, "τ").
latex_symbol(upsilon, "υ").
latex_symbol(varphi, "φ").
latex_symbol(phi, "ϕ").
latex_symbol(chi, "χ").
latex_symbol(psi, "ψ").
latex_symbol(omega, "ω").
latex_symbol(nabla, "∇").
latex_symbol(triangle, "∆").

% Hebrew letters
latex_symbol(aleph, "ℵ").
latex_symbol(bet, "ℶ").
latex_symbol(gimel, "ℷ").
latex_symbol(dalet, "ℸ").

% Binary relationships
latex_symbol(lll, "⋘").
latex_symbol(ll, "≪").
latex_symbol(lesssim, "≲").
latex_symbol(leq, "≤").
latex_symbol(leqq, "≦").
latex_symbol(approx, "≈").
latex_symbol(thickapprox, "≈").  % same as approx
latex_symbol(sim, "∼").
latex_symbol(simeq, "≃").
latex_symbol(cong, "≅").
latex_symbol(equiv, "≡").
latex_symbol(geqq, "≧").
latex_symbol(geq, "≥").
latex_symbol(gtrsim, "≳").
latex_symbol(gg, "≫").
latex_symbol(ggg, "⋙").
latex_symbol(propto, "∝").
latex_symbol(prec, "≺").
latex_symbol(precsim, "≾").
latex_symbol(preceq, "≼").
latex_symbol(curlyeqprec, "⋞").
latex_symbol(succ, "≻").
latex_symbol(succsim, "≿").
latex_symbol(succeq, "≽").
latex_symbol(curlyeqsucc, "⋟").
latex_symbol(lessgtr, "≶").
latex_symbol(lesseqgtr, "⋚").
latex_symbol(gtrless, "≷").
latex_symbol(gtreqless, "⋛").

% Negated binary relationships
latex_symbol(nless, "≮").
latex_symbol(nleq, "≰").
latex_symbol(approx, "≉").
latex_symbol(nsimeq, "≄").
latex_symbol(neq, "≠").
latex_symbol(ncong, "≇").
latex_symbol(notequiv, "≢").
latex_symbol(ngeq, "≱").
latex_symbol(ngtr, "≯").

% Other binary relations
latex_symbol(bowtie, "⋈").
latex_symbol(doteqdot, "≑").
latex_symbol(fallingdotseq, "≒").
latex_symbol(risingdotseq, "≓").
latex_symbol(circeq, "≗").
latex_symbol(vdash, "⊢").
latex_symbol(dashv, "⊣").
latex_symbol('Vdash', "⊩").
latex_symbol(vDash, "⊨").
latex_symbol('Vvdash', "⊪").

% Set operators
latex_symbol(cap, "∩").
latex_symbol(cup, "∪").
latex_symbol('Cap', "⋒").
latex_symbol('Cup', "⋓").
latex_symbol(vee, "∨").
latex_symbol(wedge, "∧").
latex_symbol(subset, "⊂").
latex_symbol(subseteq, "⊆").
latex_symbol(supseteq, "⊇").
latex_symbol(supset, "⊃").
latex_symbol('Subset', "⋐").
latex_symbol('Supset', "⋑").
latex_symbol(sqcap, "⊓").
latex_symbol(sqcup, "⊔").
latex_symbol(sqsubset, "⊏").
latex_symbol(sqsubseteq, "⊑").
latex_symbol(sqsupseteq, "⊒").
latex_symbol(sqsupset, "⊐").
latex_symbol(emptyset, "∅").
latex_symbol(in, "∈").
latex_symbol(notin, "∉").
latex_symbol(owns, "∋").
latex_symbol(complement, "∁").

% Operators
latex_symbol(pm, "±").
latex_symbol(mp, "∓").
latex_symbol(ast, "*").
latex_symbol(times, "×").
latex_symbol(centerdot, "∙").
latex_symbol(circ, "∘").
latex_symbol(div, "÷").
latex_symbol(partial, "∂").

% ⊝
latex_symbol(oplus, "⊕").
latex_symbol(ominus, "⊖").
latex_symbol(otimes, "⊗").
latex_symbol(oslash, "⊘").
latex_symbol(odot, "⊙").
latex_symbol(ocirc, "⊚").
latex_symbol(oasterisk, "⊛").
latex_symbol(boxplus, "⊞").
latex_symbol(boxminus, "⊟").
latex_symbol(boxtimes, "⊠").
latex_symbol(boxdot, "⊡").

% Mathematical logic
latex_symbol(forall, "∀").
latex_symbol(exists, "∃").
latex_symbol(nexists, "∄").
latex_symbol(therefore, "∴").
latex_symbol(because, "∵").

% Grouping
latex_symbol('{', "{").
latex_symbol('}', "}").
latex_symbol(lfloor, "⌊").
latex_symbol(rfloor, "⌋").
latex_symbol(lceil, "⌈").
latex_symbol(rceil, "⌉").
latex_symbol(vert, "|").
latex_symbol('Vert', "‖").  % norm: ||x||

% Arrows
latex_symbol(leftarrow, "←").
latex_symbol(rightarrow, "→").
latex_symbol(leftrightarrow, "↔").
latex_symbol(uparrow, "↑").
latex_symbol(downarrow, "↓").

% Miscellaneous
latex_symbol(dots, "…").
latex_symbol(infty, "∞").
latex_symbol(ldots, "…").
latex_symbol(cdots, "⋯").
latex_symbol(vdots, "⋮").
latex_symbol(ddots, "⋱").
latex_symbol(top, "T").

% Symbols in Word not yet supported: ∕*∘∙⋅⊎∥⊥≍∑∫∬∭∮∯∰∱∲∳∏∐∔∸∖⋇⋉⋊⋋⋌⋏⋎⊺†‡⋆⋄≀△⋖⋗∽≊⋍⋜⋝⊲⊳⊴⊵≖≜≏≎≬⋔≐

latex_function(sin).
latex_function(cos).
latex_function(tan).
latex_function(sinh).
latex_function(cosh).
latex_function(min).
latex_function(max).
latex_function(arg).
latex_function(log).
latex_function(det).
latex_function(trace).
