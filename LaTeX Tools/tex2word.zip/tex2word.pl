%
% tex2word: a LaTeX to Microsoft Word 2007 XML format converter
% Copyright 2010 Levente Hunyadi
%
% tex2word is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% tex2word is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%

:- encoding(utf8).
:- use_module('texdb.pl').
% :- initialization(format('tex2word: a LaTeX to Microsoft Word 2007 XML format converter~nCopyright 2010 Levente Hunyadi~n')).

%:- set_prolog_flag(toplevel_print_options, [quoted(true), portray(true), max_depth(0), attributes(portray)]).
%:- working_directory(_, 'd:/projects/tex2word').

%% tex2word(+Filepath:atom) is semidet.
% Convert a LaTeX source file to Microsoft Word 2007 XML format.
% Example: tex2word('d:/projects/tex2word/application/sample.tex').
tex2word(Filepath) :-
	catch(
		latex_to_word(Filepath),
		Exception,
		( tex2word_exception(Exception), fail )
	).

tex2word_exception(Exception) :-
	tex2word_exception(Exception, Message),
	format(user_error, 'tex2word: ~s~n', [Message]).
tex2word_exception(parse_error(Line, Column, _Position), Message) :- !,
	format(string(Message), 'Unexpected symbol in source file at line ~d column ~d', [Line, Column]).
tex2word_exception(generation_error, Message) :- !,
	format(string(Message), 'Unable to generate Office Open XML file.', []).
tex2word_exception(Exception, Message) :-  % unrecognized exception
	format(string(Message), '~w', [Exception]).

latex_to_word(Filepath) :-
	file_directory_name(Filepath, Directory),
	file_name_extension(FilepathBase, _Extension, Filepath),
	atom_concat(FilepathBase, '.ast.pl', IntermediatePath),
	( fail, exists_file(IntermediatePath) -> read_intermediate(IntermediatePath, AST)
	; read_latex(Filepath, String), parse_latex(String, AST), save_intermediate(IntermediatePath, AST)
	),
	atom_concat(Directory, '/skeleton/word/document.xml', OutputPath),
	save_word(OutputPath, AST).


%
% Parsing
%

%% read_latex(+Filename, -String:list) is det.
% Reads a LaTeX file into a string.
read_latex(Filename, String) :-
	setup_call_cleanup(
		open(Filename, read, Stream, [encoding(utf8)]),
		read_stream_string(Stream, String),
		close(Stream)
	).

%% parse_latex(+String:list, ?AST) is semidet.
% Parses a LaTeX file represented as a string into an AST.
parse_latex(String, AST) :-
	( phrase(latex_body(RedundantAST), String), !, simplify_tree(RedundantAST, AST) ; parse_latex_error(String) ).

%% simplify_tree(+AST, -SimplerAST) is det.
% SimplerAST is a simplified abstract syntax tree.
simplify_tree(T, S) :-
	( is_list(T) -> simplify_list(T, S)
	; compound(T) -> simplify_compound(T, S)
	; T = S
	).

%% simplify_compound(+T, -ST) is det.
% ST is a compound term all of whose arguments are simplified abstract syntax subtrees.
simplify_compound(T, ST) :-
	T =.. [N|A],
	simplify_compound_args(A, SA),
	ST =.. [N|SA].

simplify_compound_args([H|T], [SH|ST]) :-
	simplify_tree(H, SH),
	simplify_compound_args(T, ST).
simplify_compound_args([], []).
	
%% simplify_compound(+Items, -SimplerItems) is det.
% SimplerItems is a list of simplified abstract syntax subtrees where some neighboring items have been contracted into a single item.
simplify_list([text(A),text(B)|Tail], Items) :- !,  % concatenate text nodes
	string_concat(A, B, C),
	simplify_list([text(C)|Tail], Items).
simplify_list([H|Tail], [SH|Items]) :- !,
	simplify_tree(H, SH),
	simplify_list(Tail, Items).
simplify_list([], []).

%% parse_latex_error(+Codes) is det.
% Issues an exception that an error has occurred while parsing Codes.
parse_latex_error(Codes) :-
	nb_getval(characters_left, Remains),
	string_to_list(String, Codes),
	sub_string(String, 0, Position, Remains, Consumed),
	line_column_position(Consumed, Line, Column),
	throw(parse_error(Line, Column, Position)).

parse_position(String) :-
	length(String, StringLength),
	nb_setval(characters_left, StringLength).
parse_position(String, String) :-  % for calling within DCG rules
	parse_position(String).

latex_body(Body) -->
	parse_position,
	latex_preamble,
	"\\begin{document}", newlines,  % .tex file may begin with arbitary number of newlines
	parse_position,
	latex_paragraphs(Body),
	"\\end{document}", newlines.

latex_preamble -->
	( "\\%", !, latex_preamble
	; latex_comment, !, latex_preamble
	; \+ "\\begin{document}" -> [_], latex_preamble
	; []
	).

whitespace --> ( "\r" ; "\n" ; "\t" ; " " ), !, whitespace.
whitespace --> [].
	
newlines --> ( latex_comment, ! ; "\n" ), !, newlines.
newlines --> [].

% An entire LaTeX document body.
latex_paragraphs([Head|Tail]) -->
	( latex_text_command(section, Optional, [Title]) ->                        { Head = section(Optional, Title) }  % no other text is permitted on section declaration line
	; latex_text_command(subsection, Optional, [Title]) ->                     { Head = subsection(Optional, Title) }
	; latex_text_command(subsubsection, Optional, [Title]) ->                  { Head = subsubsection(Optional, Title) }
	; latex_text_command(paragraph, Optional, [Title]) ->                      { Head = subsubsubsection(Optional, Title) }
	; latex_tabular(Tabular) ->                                                { Head = table(Tabular) }
	; latex_paragraph(Paragraph),                                              { Head = paragraph(Paragraph) }  % regular text (not identical to LaTeX's \paragraph{...})
	),
	( "\n\n", !, newlines, latex_paragraphs(Tail) ; { Tail = [] } ).  % at least two newlines separate paragraphs
latex_paragraphs([]) --> [].

latex_paragraph_collapse([text(A),text(B)|Tail], Paragraph) :- !,
	string_concat(A, B, C),
	latex_paragraph_collapse([text(C)|Tail], Paragraph).
latex_paragraph_collapse([Head|Tail], [Head|Paragraph]) :- !,
	latex_paragraph_collapse(Tail, Paragraph).
latex_paragraph_collapse([], []).

%% latex_paragraph_item(-Item, +Context) is semidet.
% Item is an item in a LaTeX paragraph where Context restricts the set of permissible characters for text.
latex_paragraph_item(Item, Context) -->
	( latex_comment ->                                                         { Item = [] }
	; "\\\\" ->                                                                { Item = newline }
	; "$" -> latex_formula(Formula), "$",                                      { Item = inline_formula(Formula) }
	; "\\[" -> latex_formula(Formula), "\\]",                                  { Item = display_formula(Formula) }
	; "\\begin{equation}" -> latex_formula(Formula), "\\end{equation}",        { Item = equation(Formula) }
	; latex_eqnarray(Formula) ->                                               { Item = Formula }
	; latex_text_environment(Environment, Optional, Arguments, Body) ->        { Item = environment(Environment, Optional, Arguments, Body) }
	; latex_text_character(Character) ->                                       { Item = text(Character) }
	; latex_text_command(Command, Optional, Arguments) ->                      { Item = command(Command, Optional, Arguments) }
	; latex_text(Text, Context) ->                                             { Item = text(Text) }
	).

latex_paragraph_common(Paragraph, Context) -->
	latex_paragraph_item(Item, Context), !,
	parse_position,
	{ Item \= [] -> Paragraph = [Item|Tail] ; Paragraph = Tail },
	latex_paragraph_common(Tail, Context).
latex_paragraph_common([], _Context) --> [].

latex_paragraph(Paragraph) --> latex_paragraph_common(Paragraph, regular_context).

latex_paragraph_optarg(Paragraph) --> latex_paragraph_common(Paragraph, optional_context).

latex_paragraph_tabular_item(Item) -->
	( latex_comment,                                                           { Item = [] }
	; "\\\\", !, {fail}
	; "\\tabularnewline", !, {fail}
	; "$", !, latex_formula(Formula), "$",                                     { Item = inline_formula(Formula) }
	; latex_text_character(Character),                                         { Item = text(Character) }
	; latex_text_command(Command, Optional, Arguments),                        { Item = command(Command, Optional, Arguments) }
	; latex_text(Text, regular_context),                                       { Item = text(Text) }
	), !.

latex_paragraph_tabular(Items) -->
	latex_paragraph_tabular_item(Item), !,
	parse_position,
	{ Item \= [] -> Items = [Item|Tail] ; Items = Tail },
	latex_paragraph_tabular(Tail).
latex_paragraph_tabular([]) --> [].
	
latex_comment --> "%", latex_comment_chars.
latex_comment_chars --> ( "\n", ! ; [_], latex_comment_chars ).

% Regular LaTeX document text.
latex_text(Text, Context) -->
	latex_text_char(C, Context),  % text must contain at least a single character
	latex_text_chars(Chars, Context),
	{ string_to_list(Text, [C|Chars]) }.
latex_text_chars([C|Chars], Context) -->
	latex_text_char(C, Context), !, latex_text_chars(Chars, Context).
latex_text_chars([], _Context) --> [].

latex_text_char(Char, Context) -->
	( "\\" -> [E], { memberchk(E, " #$%&_{}"), Char = E }
	; latex_special(C), !, { atom_codes(C, [Char]) }
	; "\n\n" -> { fail }     % end of paragraph
	; [C], { integer(C), latex_text_char_accept(Context, C), Char = C }
	).

latex_text_char_accept(regular_context, Char) :-
	\+ memberchk(Char, "#$%&~_^\\{}").
latex_text_char_accept(optional_context, Char) :-
	\+ memberchk(Char, "#$%&~_^\\{}[]").

% Special characters
latex_text_character(Character) --> "\\", latex_character(Character).

% Whitespace inside a formula.
latex_formula_whitespace --> ( "\r" ; "\n" ; "\t" ; " " ), !.
latex_formula_whitespace --> [].

% Tabular environment
latex_tabular(Tabular) -->
	latex_environment_begin("tabular"),
	"{", latex_command_arg(_Layout, latex_paragraph_tabular), "}",
	latex_tabular_rows(Tabular),
	latex_environment_end("tabular").

latex_tabular_rows(Tabular) -->
	whitespace, 
	( "\\hline", !, latex_tabular_rows(Tabular)
	; latex_tabular_cols(Row),
		( "\\\\", !, { Tabular = [Row|Rows] }, latex_tabular_rows(Rows)
		; "\\tabularnewline", !, { Tabular = [Row|Rows] }, latex_tabular_rows(Rows)
		; { Tabular = [] }
		)
	; { Tabular = [] }
	).

latex_tabular_cols([Col|Cols]) -->
	latex_command_arg(Col, latex_paragraph_tabular),
	( "&", !, whitespace, latex_tabular_cols(Cols) ; { Cols = [] } ).

% An inline or display formula.
latex_formula(Formula) -->
	latex_formula_helper(Items),
	{ once(phrase(latex_formula_grouping(Formula), Items)) }.

latex_formula_optarg(Formula) --> latex_formula(Formula).

latex_formula_helper(L) -->
	latex_formula_whitespace,  % skip whitespace in formulas
	( latex_subsuperscript(Symbol, Subscript, Superscript) ->    { Formula = subsuperscript(Symbol, Subscript, Superscript) }  % e.g. \sum_{k=0}^N
	; latex_subscript(Symbol, Subscript) ->                      { Formula = subscript(Symbol, Subscript) }
	; latex_superscript(Symbol, Superscript) ->                  { Formula = superscript(Symbol, Superscript) }
	; latex_matrix(Matrix) ->                                    { Formula = Matrix }
	; latex_cases(Matrix) ->                                     { Formula = Matrix }
	; latex_formula_environment(Name, Optional, Args, Body) ->   { Formula = environment(Name, Optional, Args, Body) }
	; latex_formula_command(Name, Optional, Args) ->             { Formula = command(Name, Optional, Args) }
	; latex_formula_group(Group) ->                              { Group = [Entry] -> Formula = Entry ; Formula = Group }
	; latex_formula_symbol(Symbol) ->                            { Formula = Symbol }
	), !,
	{ L = [Formula|T] },
	latex_formula_helper(T).
latex_formula_helper([]) --> latex_formula_whitespace.

latex_formula_grouping(Items) -->
	[command(left, default, []), Begin], !,
	{ word_formula_grouping_chars(Begin, BeginChars) },
	latex_formula_grouping(Group),
	[command(right, default, []), End],
	{ latex_formula_grouping_termination(End, BeginChars, Group, Items, T) },
	latex_formula_grouping(T).
latex_formula_grouping([H|T]) --> [H], { H \= command(right, default, []) }, latex_formula_grouping(T).
latex_formula_grouping([]) --> [].

latex_formula_grouping_termination(End, BeginChars, Group, Items, T) :-
	latex_formula_grouping_termination(End, BeginChars, Group, R),
	Items = [R|T].

%% latex_formula_grouping_termination(+E, +B, +G, -R) is semidet.
% R is term that wraps all parenthesizes elements G annotated with any suffixes (e.g. subscripts and superscripts) in E.
latex_formula_grouping_termination(subsuperscript(End, Subscript, Superscript), BeginChars, Group, subsuperscript(group(Group, BeginChars, EndChars), Subscript, Superscript)) :-
	word_formula_grouping_chars(End, EndChars).
latex_formula_grouping_termination(subscript(End, Subscript), BeginChars, Group, subscript(group(Group, BeginChars, EndChars), Subscript)) :-
	word_formula_grouping_chars(End, EndChars).
latex_formula_grouping_termination(superscript(End, Superscript), BeginChars, Group, superscript(group(Group, BeginChars, EndChars), Superscript)) :-
	word_formula_grouping_chars(End, EndChars).
latex_formula_grouping_termination(End, BeginChars, Group, group(Group, BeginChars, EndChars)) :-
	word_formula_grouping_chars(End, EndChars).

% Grouping
word_formula_grouping_chars(command(Symbol, default, []), S) :- !, latex_symbol(Symbol, S).
word_formula_grouping_chars(Symbol, S) :- atom(Symbol), atom_codes(Symbol, S).

% A subscripted formula.
latex_subscript(Symbol, Subscript) -->
	latex_script(Symbol, Subscript, 0'_).

% A superscripted formula.
latex_superscript(Symbol, Superscript) -->
	latex_script(Symbol, Superscript, 0'^).

latex_script(SymbolLarge, SymbolSmall, Separator) -->
	latex_formula_element(SymbolLarge),
	[Separator],
	latex_formula_element(SymbolSmall).

% A LaTeX element inside a formula.
latex_formula_element(Element) -->
	latex_formula_whitespace,
	( latex_formula_command(Command, Optional, Argument), !, { Element = command(Command, Optional, Argument) }
	; latex_formula_group(Group), !, { Group = [Entry] -> Element = Entry ; Element = Group }
	; latex_formula_symbol(Element)
	),
	latex_formula_whitespace.

% A sub- and superscripted formula.
latex_subsuperscript(Symbol, Subscript, Superscript) -->
	latex_formula_element(Symbol),
	"_",
	latex_formula_element(Subscript),
	"^",
	latex_formula_element(Superscript).

% A LaTeX group enclosed by { }.
latex_formula_group(Group) --> "{", latex_formula(Group), "}".

latex_environment_begin(Identifier) -->
	"\\begin{", Identifier, "}".

latex_environment_end(Identifier) -->
	"\\end{", Identifier, "}".

latex_eqnarray(Formula) -->
	latex_environment_begin("eqnarray*"),
	latex_matrix_rows(Matrix),
	{ transpose(Matrix, [_EqnLeft, _EqnMiddle, _EqnRight]) },  % make sure rows have the format x & = & y \\
	latex_environment_end("eqnarray*"),
	{ Formula = equation([matrix(Matrix, [r,m,l], default)]) }.

latex_matrix(Formula) -->
	latex_environment_begin("array"),
	( "[", latex_command_arg(VertAlign, latex_formula_optarg), "]" ; { VertAlign = default } ),
	"{", latex_command_arg(HorzAlign, latex_formula), "}",
	latex_matrix_rows(Matrix),
	latex_environment_end("array"),
	{ Formula = matrix(Matrix, HorzAlign, VertAlign) }.

latex_matrix_rows([Row|Rows]) --> latex_matrix_cols(Row), ( "\\\\", !, latex_matrix_rows(Rows) ; { Rows = [] } ).

latex_matrix_cols([Col|Cols]) -->
	( latex_command_arg(Col, latex_formula), ! ; { Col = [] } ),
	( "&", !, latex_matrix_cols(Cols) ; { Cols = [] } ).

latex_cases(Formula) -->
	latex_environment_begin("cases"),
	latex_matrix_rows(Matrix),
	latex_environment_end("cases"),
	{ Formula = group([matrix(Matrix, [l,l], default)], "{", "") }.

% A LaTeX environment outside a formula.
latex_text_environment(Environment, Optional, Arguments, Body) --> latex_environment(Environment, Optional, Arguments, Body, latex_paragraphs).

% A LaTeX environment inside a formula.
latex_formula_environment(Environment, Optional, Arguments, Body) --> latex_environment(Environment, Optional, Arguments, Body, latex_formula).

% A LaTeX environment \begin{environment}[optional]{argument1}{argument2}...\end{environment} inside or outside a formula.
latex_environment(Environment, Optional, Arguments, Body, Context) -->
	"\\begin{", latex_identifier(Environment), "}",
	( "[", latex_command_arg(Optional, Context), "]" ; { Optional = default } ),
	latex_command_args(Arguments, Context),
	latex_command_arg(Body, Context),  % environment body
	"\\end{", latex_identifier(Environment), "}".

% A LaTeX command \command[optional]{argument} outside a formula.
latex_text_command(Command, Optional, Arguments) --> latex_command(Command, Optional, Arguments, latex_paragraph, latex_paragraph_optarg).

% A LaTeX command \command[optional]{argument} inside a formula.
latex_formula_command(Command, Optional, Arguments) --> latex_command(Command, Optional, Arguments, latex_formula, latex_formula_optarg).

% A LaTeX command \command[optional]{argument1}{argument2}... inside or outside a formula.
latex_command(Command, Optional, Arguments, RegularContext, OptionalContext) -->
	"\\", latex_identifier(Command),
	{ \+ memberchk(Command, [begin,end]) },  % environment open/close tags not allowed as command identifiers
	( "[", latex_command_arg(Optional, OptionalContext), "]" ; { Optional = default } ),
	latex_command_args(Arguments, RegularContext).

% A LaTeX command argument list.
latex_command_args(Arguments, Context) -->
	"{", !,
	latex_command_arg(Arg, Context),
	"}",
	{ Arguments = [Arg|Args] },
	latex_command_args(Args, Context).
latex_command_args([], _Context) --> [].

latex_command_arg(Arg, Context) --> ( call(Context, Arg), ! ; { Arg = [] } ).

% An identifier for a LaTeX command.
latex_identifier(Identifier) --> latex_identifier_characters(Chars), { atom_codes(Identifier, Chars) }.
latex_identifier_characters([C|Identifier]) -->
	[C],
	( { is_alpha(C) } -> latex_identifier_chars(Identifier)
	; { memberchk(C, ";:,!{}") } -> { Identifier = [] }  % thick, medium, thin and negative thin space, grouping
	).
latex_identifier_chars([C|Identifier]) --> [C], { is_alpha(C) }, !, latex_identifier_chars(Identifier).
latex_identifier_chars("*") --> "*", !.
latex_identifier_chars([]) --> [].

% A single-character symbol in a LaTeX formula.
latex_formula_symbol(Symbol) --> [C], { \+ memberchk(C, "#$%&~_^\\{}"), !, atom_char(Symbol, C) }.

% C is a lowercase or uppercase letter.
is_alpha(C) :- ( C >= 0'A, C =< 0'Z, ! ; C >= 0'a, C =< 0'z ).

% C is a digit.
is_num(C) :- C >= 0'0, C =< 0'9.

% C is a lowercase or uppercase letter, or a digit.
is_alphanum(C) :- ( is_alpha(C), ! ; is_num(C) ).

%
% Code generation
%

read_intermediate(Filename, AST) :-
	setup_call_cleanup(
		open(Filename, read, Stream, [encoding(utf8)]),
		read_term(Stream, AST, [backquoted_string(true)]),
		close(Stream)
	).

save_intermediate(Filename, AST) :-
	setup_call_cleanup(
		create_file(Filename, Stream),
		pretty_print(Stream, AST),
		close(Stream)
	).

save_word(Filename, AST) :-
	setup_call_cleanup(
		create_file(Filename, Stream),
		write_word(Stream, AST),
		close(Stream)
	).

write_word(Stream, AST) :-
	phrase(word_document(AST), String),	!,
	format(Stream, '~s', [String]).
write_word(_Stream, _AST) :-
	throw(generation_error).

word_document(Content) -->
	"<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<w:document xmlns:ve=\"http://schemas.openxmlformats.org/markup-compatibility/2006\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:m=\"http://schemas.openxmlformats.org/officeDocument/2006/math\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:w10=\"urn:schemas-microsoft-com:office:word\" xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:wne=\"http://schemas.microsoft.com/office/word/2006/wordml\"><w:body>",
	word_paragraphs(Content),
	"<w:sectPr><w:pgSz w:w='12240' w:h='15840'/><w:pgMar w:top='1440' w:right='1440' w:bottom='1440' w:left='1440' w:header='720' w:footer='720' w:gutter='0'/><w:cols w:space='720'/><w:docGrid w:linePitch='360'/></w:sectPr></w:body></w:document>".

word_paragraphs([Head|Tail]) --> word_paragraph(Head), word_paragraphs(Tail).
word_paragraphs([]) --> [].

% Sectioning
word_paragraph(section(_Optional, Title)) -->
	word_styled_paragraph(Title, "Heading1", "0").
word_paragraph(subsection(_Optional, Title)) -->
	word_styled_paragraph(Title, "Heading2", "1").
word_paragraph(subsubsection(_Optional, Title)) -->
	word_styled_paragraph(Title, "Heading3", "2").
word_paragraph(subsubsubsection(_Optional, Title)) -->  % LaTeX "paragraph" command
	word_styled_paragraph(Title, "Heading4", "3").
word_paragraph(table(Table)) --> !,
	word_table(Table).
word_paragraph(paragraph(Paragraph)) -->
	"<w:p>",
	word_paragraph_items(Paragraph, []),
	"</w:p>".

word_styled_paragraph(Text, Style, Level) -->
	"<w:p><w:pPr><w:pStyle w:val=\"", Style, "\"/>",
	"<w:numPr><w:ilvl w:val=\"", Level, "\"/><w:numId w:val=\"1\"/></w:numPr>",  % numbering
	"</w:pPr>",
	word_paragraph_items(Text, []),
	"</w:p>".

word_paragraph_items([Head|Tail], Modifiers) --> !, word_paragraph_item(Head, Modifiers), word_paragraph_items(Tail, Modifiers).
word_paragraph_items([], _Modifiers) --> [].

word_paragraph_item(newline) --> !,
	"<w:r>",
	word_font,
	"<w:br/></w:r>".
word_paragraph_item(equation(Formula), _Modifiers) --> !, word_paragraph_item(display_formula(Formula), []).
word_paragraph_item(display_formula(Formula), _Modifiers) --> !,
	"<w:r>",
	word_font,
	"<w:br/></w:r><m:oMathPara>",
	word_paragraph_item(inline_formula(Formula), []),
	"</m:oMathPara><w:r>",
	word_font,
	"<w:br/></w:r>".
word_paragraph_item(inline_formula(Formula), _Modifiers) --> !, "<m:oMath>", word_formula(Formula), "</m:oMath>".
word_paragraph_item(text(Text), Modifiers) --> !,
	word_paragraph_text(Text, Modifiers).
word_paragraph_item(command(Command, Optional, Arguments), Modifiers) -->
	word_paragraph_command(Command, Optional, Arguments, Modifiers), !.
word_paragraph_item(environment(_Environment, _Optional, _Arguments, _Body), _Modifiers) -->
	!.

word_paragraph_text(Text, Modifiers) -->
	"<w:r>",
	word_font(Modifiers),
	"<w:t xml:space=\"preserve\">",
	{ string(Text) -> string_to_list(Text, Codes)
	; atom(Text) -> atom_codes(Text, Codes)
	; Text = Codes
	},
	Codes,
	"</w:t></w:r>".

% Formatting
word_paragraph_command(emph, [Body], Modifiers) --> !,
	( { select(italic, Modifiers, AlteredModifiers) } -> word_paragraph_items(Body, AlteredModifiers)
	; word_paragraph_items(Body, [italic|Modifiers])
	).
word_paragraph_command(textbf, [Body], Modifiers) --> !,
	word_paragraph_items(Body, [bold|Modifiers]).
word_paragraph_command(textit, [Body], Modifiers) --> !,
	word_paragraph_items(Body, [italic|Modifiers]).
word_paragraph_command(textsc, [Body], Modifiers) --> !,
	word_paragraph_items(Body, [smallcaps|Modifiers]).

% References
word_paragraph_command(url, [[text(URL)]], _Modifiers) --> !,
	"<w:hyperlink w:history=\"1\"><w:r><w:rPr><w:rStyle w:val=\"Hyperlink\"/></w:rPr><w:t>",  % no entry is added to document.xml.rels (Word relationships XML)
	any_codes(URL),
	"</w:t></w:r></w:hyperlink>".
word_paragraph_command(label, [Reference], _Modifiers) --> !,
	"<w:bookmarkStart w:id=\"0\" w:name=\"_Ref",
	{ term_hash_codes(Reference, HashCodes) }, HashCodes,
	"\"/>",
	% "<w:fldSimple w:instr=\" SEQ Figure \\* ARABIC \">", "</w:fldSimple>",  % numbering for figures
	"<w:bookmarkEnd w:id=\"0\"/>".
word_paragraph_command(ref, [Reference], Modifiers) --> !,
	{ term_hash_codes(Reference, HashCodes) },
	"<w:fldSimple w:instr=\" REF  _Ref", HashCodes, " \\h \\r \">",
	word_paragraph_text("[Ref]", Modifiers),
	"</w:fldSimple>".
word_paragraph_command(cite, [[text(Reference)]], Modifiers) --> !,
	"<w:sdt><w:sdtPr><w:citation/></w:sdtPr><w:sdtContent><w:r><w:fldChar w:fldCharType=\"begin\"/></w:r><w:r><w:rPr></w:rPr><w:instrText xml:space=\"preserve\"> CITATION ",
	any_codes(Reference),
	{ string_to_list(Reference, Codes) }, Codes,
	" </w:instrText></w:r><w:r><w:fldChar w:fldCharType=\"separate\"/></w:r>",
	{ format(string(Label), '[Ref:~s]', [Reference]) },
	word_paragraph_text(Label, Modifiers),
	"<w:r><w:fldChar w:fldCharType=\"end\"/></w:r></w:sdtContent></w:sdt>".

% Miscellaneous
word_paragraph_command(Command, _Args, Modifiers) -->
	{ format(string(String), '[!def:~s]', [Command]) },
	word_paragraph_text(String, Modifiers).

% Miscellaneous with optional argument
word_paragraph_command(Command, default, Arguments, Modifiers) --> !,
	word_paragraph_command(Command, Arguments, Modifiers).
word_paragraph_command(Command, _Optional, _Args, Modifiers) -->
	{ format(string(String), '[!def:~s]', [Command]) },
	word_paragraph_text(String, Modifiers).


% Tables
word_table(Table) -->
	"<w:tbl><w:tblPr><w:tblStyle w:val=\"TableGrid\"/><w:tblW w:w=\"0\" w:type=\"auto\"/><w:tblLook w:val=\"04A0\"/></w:tblPr>",
	"<w:tblGrid></w:tblGrid>",  % use default layout (do not add <w:gridCol w:w="4788"/>)
	word_table_rows(Table),
	"</w:tbl>".

word_table_rows([Row|Rows]) -->
	"<w:tr>",
	word_table_cells(Row),
	"</w:tr>",
	word_table_rows(Rows).
word_table_rows([]) --> [].

word_table_cells([Col|Cols]) -->
	"<w:tc><w:tcPr><w:tcW w:w=\"4788\" w:type=\"dxa\"/></w:tcPr><w:p>",
	word_paragraph_items(Col, []),
	"</w:p></w:tc>",
	word_table_cells(Cols).
word_table_cells([]) --> [].

word_formula(Items) --> word_formula(Items, []).
word_formula([Head|Tail], Modifiers) --> !, word_formula_element(Head, Modifiers), word_formula(Tail, Modifiers).
word_formula([], _Modifiers) --> [].

word_formula_element([H|T], Modifiers) --> !,
	word_formula([H|T], Modifiers).
word_formula_element([], _Modifiers) --> !.
word_formula_element(group(Group, BeginChar, EndChar), Modifiers) --> !,
	"<m:d><m:dPr><m:begChr m:val=\"",
	BeginChar,
	"\"/><m:endChr m:val=\"",
	EndChar,
	"\"/>",
	word_math_font_ctrl,
	"</m:dPr><m:e>",
	word_formula_element(Group, Modifiers),
	"</m:e></m:d>".
word_formula_element(subsuperscript(Symbol, Subscript, Superscript), Modifiers) --> !,
	word_formula_subsuperscript(Symbol, Subscript, Superscript, Modifiers).
word_formula_element(superscript(Symbol, Superscript), Modifiers) --> !,
	word_formula_superscript(Symbol, Superscript, Modifiers).
word_formula_element(subscript(Symbol, Subscript), Modifiers) --> !,
	word_formula_subscript(Symbol, Subscript, Modifiers).
word_formula_element(command(Command, Optional, Arguments), Modifiers) --> !,
	( { Optional = default } -> word_formula_command(Command, Arguments, Modifiers)
	; word_formula_command(Command, Optional, Arguments, Modifiers)
	).
word_formula_element(matrix(Matrix, HorzAlign, VertAlign), Modifiers) --> !,
	word_formula_matrix(Matrix, HorzAlign, VertAlign, Modifiers).
word_formula_element(environment(Environment, Optional, Arguments, Body), Modifiers) --> !,
	word_formula_environment(Environment, Optional, Arguments, Body, Modifiers).
word_formula_element(Atom, Modifiers) -->
	{ atom(Atom) }, !,
	"<m:r>",
	word_modifiers(Modifiers),
	word_math_font,
	"<m:t>",
	{ Atom = '&' -> Codes = "&amp;"
	; Atom = '<' -> Codes = "&lt;"
	; Atom = '>' -> Codes = "&gt;"
	; atom_codes(Atom, Codes)
	}, Codes,
	"</m:t></m:r>".

% Sub- and superscript
word_formula_subsuperscript(command(Operator, default, []), Subscript, Superscript, Modifiers) -->  % LaTeX big operators
	word_formula_nary(Operator, Subscript, Superscript, Modifiers), !.
word_formula_subsuperscript(Symbol, Subscript, Superscript, Modifiers) --> !,  % regular combined sub- and superscript
	"<m:sSubSup><m:sSubSupPr>",
	word_math_font_ctrl,
	"</m:sSubSupPr><m:e>",
	word_formula_element(Symbol, Modifiers),
	"</m:e><m:sub>",
	word_formula_element(Subscript, Modifiers),
	"</m:sub><m:sup>",
	word_formula_element(Superscript, Modifiers),
	"</m:sup></m:sSubSup>".

% Superscript
word_formula_superscript(command(Operator, default, []), Superscript, Modifiers) -->  % LaTeX big operators
	word_formula_nary(Operator, [], Superscript, Modifiers), !.
word_formula_superscript(SymbolLarge, SymbolSmall, Modifiers) --> !,  % regular superscript
	"<m:sSup><m:sSupPr>",
	word_math_font_ctrl,
	"</m:sSupPr><m:e>",
	word_formula_element(SymbolLarge, Modifiers),
	"</m:e><m:sup>",
	word_formula_element(SymbolSmall, Modifiers),
	"</m:sup></m:sSup>".

% Subscript
word_formula_subscript(command(Operator, default, []), Subscript, Modifiers) -->  % LaTeX big operators
	word_formula_nary(Operator, Subscript, [], Modifiers), !.
word_formula_subscript(command(Command, default, []), SymbolSmall, Modifiers) -->
	{ latex_function(Command) }, !,
	word_formula_subscripted_function(Command, SymbolSmall, Modifiers).
word_formula_subscript(SymbolLarge, SymbolSmall, Modifiers) --> !,  % regular subscript
	"<m:sSub><m:sSubPr>",
	word_math_font_ctrl,
	"</m:sSubPr><m:e>",
	word_formula_element(SymbolLarge, Modifiers),
	"</m:e><m:sub>",
	word_formula_element(SymbolSmall, Modifiers),
	"</m:sub></m:sSub>".

% Commands without optional argument

% Labels
word_formula_command(label, [_Argument], _Modifiers) --> !.

% Formatting
word_formula_command(protect, [], _Modifiers) --> !.
word_formula_command(mathrm, [Argument], Modifiers) --> !,
	word_formula(Argument, [plain|Modifiers]).
word_formula_command(mathbf, [Argument], Modifiers) --> !,
	word_formula(Argument, [bold|Modifiers]).
word_formula_command(mathbb, [Argument], Modifiers) --> !,
	word_formula(Argument, [blackboard|Modifiers]).
word_formula_command(mathcal, [Argument], Modifiers) --> !,
	word_formula(Argument, [calligraphic|Modifiers]).
word_formula_command(mathfrak, [Argument], Modifiers) --> !,
	word_formula(Argument, [fraktur|Modifiers]).
word_formula_command(boldsymbol, [Argument], Modifiers) --> !,
	word_formula(Argument, [bold,italic|Modifiers]).
word_formula_command(qquad, [], _Modifiers) --> !,  % quad space
	word_formula_text("    ").
word_formula_command(quad, [], _Modifiers) --> !,  % quad space
	word_formula_text("   ").
word_formula_command(';', [], _Modifiers) --> !,  % thick space
	word_formula_text("  ").
word_formula_command(':', [], _Modifiers) --> !,  % medium space
	word_formula_text(" ").
word_formula_command(fbox, [Argument], Modifiers) --> !,
	"<m:borderBox><m:borderBoxPr>",
	word_math_font_ctrl,
	"</m:borderBoxPr><m:e>",
	word_formula_element(Argument, Modifiers),
	"</m:e></m:borderBox>".

% Fractions
word_formula_command(frac, [Numerator,Denominator], Modifiers) --> !,
	"<m:f><m:fPr>",
	word_math_font_ctrl,
	"</m:fPr><m:num>",
	word_formula_element(Numerator, Modifiers),
	"</m:num><m:den>",
	word_formula_element(Denominator, Modifiers),
	"</m:den></m:f>".

% Radical sign
word_formula_command(sqrt, [Radicand], Modifiers) --> !,
	"<m:rad><m:radPr><m:degHide m:val=\"on\"/>",
	word_math_font_ctrl,
	"</m:radPr><m:deg/><m:e>",
	word_formula_element(Radicand, Modifiers),
	"</m:e></m:rad>".

% Big operators
word_formula_command(Operator, [], Modifiers) -->
	word_formula_nary(Operator, [], [], Modifiers), !.

% Accents
word_formula_command(Accent, [Argument], Modifiers) -->
	{ latex_accent(Accent, A) }, !, word_formula_accent(A, Argument, Modifiers).

% Symbols
word_formula_command(Symbol, [], Modifiers) -->
	{ latex_symbol(Symbol, S) }, !, word_formula_symbol(S, Modifiers).

% Common mathematical functions, e.g. sin, cos, etc.
word_formula_command(Command, [], _Modifiers) -->
	{ latex_function(Command) }, !, word_formula_function(Command).

% Unrecognized command
word_formula_command(Command, Arguments, _Modifiers) -->
	{ sformat(String, '{!def:~s ~w}', [Command, Arguments]) },
	word_formula_text(String).

% Commands with optional argument

% Radical sign with degree
word_formula_command(sqrt, Degree, [Radicand], Modifiers) --> !,
	"<m:rad><m:radPr>",
	word_math_font_ctrl,
	"</m:radPr><m:deg>",
	word_formula_element(Degree, Modifiers),
	"</m:deg><m:e>",
	word_formula_element(Radicand, Modifiers),
	"</m:e></m:rad>".

% Unrecognized command
word_formula_command(Command, Optional, Arguments, _Modifiers) -->
	{ sformat(String, '{!def:~s ~w ~w}', [Command, Optional, Arguments]) },
	word_formula_text(String).

word_formula_environment(_Name, _Optional, _Arguments, _Body, _Modifiers) --> !.

word_formula_text(Characters) -->
	"<m:r>",
	word_math_font,
	"<m:t xml:space=\"preserve\">",
	Characters,
	"</m:t></m:r>".

word_formula_nary(Symbol, Subscript, Superscript, Modifiers) -->
	"<m:nary><m:naryPr>",
	( { Symbol \= [] } -> "<m:chr m:val=\"", { latex_operator(Symbol, S) }, S, "\"/>" ; [] ),
	"<m:limLoc m:val=\"undOvr\"/>",
	( { Subscript == [] } -> "<m:subHide m:val=\"on\"/>" ; [] ),
	( { Superscript == [] } -> "<m:supHide m:val=\"on\"/>" ; [] ),
	word_math_font_ctrl,
	"</m:naryPr><m:sub>",
	( { Subscript \= [] } -> word_formula_element(Subscript, Modifiers) ; [] ),
	"</m:sub><m:sup>",
	( { Superscript \= [] } -> word_formula_element(Superscript, Modifiers) ; [] ),
	"</m:sup><m:e>",
	word_formula_text("​"),  % insert zero-width space placeholder
	"</m:e></m:nary>".

word_formula_subscripted_function(Function, Subscript, Modifiers) -->
	"<m:func><m:funcPr>",
	word_math_font_ctrl,
	"</m:funcPr><m:fName><m:limLow><m:limLowPr>",
	word_math_font_ctrl,
	"</m:limLowPr><m:e><m:r><m:rPr><m:sty m:val=\"p\"/></m:rPr>",
	word_math_font,
	"<m:t>",
	{ atom_codes(Function, Codes) }, Codes,
	"</m:t></m:r></m:e><m:lim>",
	word_formula_element(Subscript, Modifiers),
	"</m:lim></m:limLow></m:fName><m:e>",
	word_formula_text("​"),  % insert zero-width space placeholder
	"</m:e></m:func>".

word_formula_function(Function) -->
	"<m:func><m:funcPr>",
	word_math_font_ctrl,
	"</m:funcPr><m:fName><m:r><m:rPr><m:sty m:val=\"p\"/></m:rPr>",
	word_math_font,
	"<m:t>",
	{ atom_codes(Function, Codes) }, Codes,
	"</m:t></m:r></m:fName><m:e>",
	word_formula_text("​"),  % insert placeholder
	"</m:e></m:func>".

word_formula_matrix(Matrix, _HorzAlign, _VertAlign, Modifiers) -->
	"<m:m><m:mPr><m:mcs><m:mc><m:mcPr><m:count m:val=\"",
	{ Matrix = [Row|_], length(Row, Count), atom_codes(Count, C) }, C,
	"\"/><m:mcJc m:val=\"center\"/></m:mcPr></m:mc></m:mcs>",
	word_math_font_ctrl,
	"</m:mPr>",
	word_formula_matrix_rows(Matrix, Modifiers),
	"</m:m>".

word_formula_matrix_rows([Row|Rows], Modifiers) -->
	"<m:mr>",
	word_formula_matrix_cells(Row, Modifiers),
	"</m:mr>",
	word_formula_matrix_rows(Rows, Modifiers).
word_formula_matrix_rows([], _Modifiers) --> [].

word_formula_matrix_cells([Cell|Cells], Modifiers) -->
	"<m:e>",
	word_formula_element(Cell, Modifiers),
	"</m:e>",
	word_formula_matrix_cells(Cells, Modifiers).
word_formula_matrix_cells([], _Modifiers) --> [].

word_formula_accent(Accent, Symbol, Modifiers) -->
	"<m:acc><m:accPr><m:chr m:val=\"",
	Accent,
	"\"/>",
	word_math_font_ctrl,
	"</m:accPr><m:e>",
	word_formula(Symbol, Modifiers),
	"</m:e></m:acc>".

word_formula_symbol(Symbol, Modifiers) -->
	"<m:r>",
	word_modifiers(Modifiers),
	word_math_font,
	"<m:t>",
	Symbol,
	"</m:t></m:r>".

word_font --> word_font([]).
word_font(M) --> "<w:rPr>", word_font_selector, word_font_modifiers(M), "</w:rPr>".
word_font_selector --> "<w:rFonts w:eastAsiaTheme=\"minorEastAsia\"/>".
word_font_modifiers([H|T]) --> word_font_modifier(H), word_font_modifiers(T).
word_font_modifiers([]) --> [].
word_font_modifier(bold) --> !, "<w:b/>".
word_font_modifier(italic) --> !, "<w:i/>".
word_font_modifier(smallcaps) --> !, "<w:smallCaps/>".
word_math_font --> "<w:rPr><w:rFonts w:ascii=\"Cambria Math\" w:hAnsi=\"Cambria Math\"/></w:rPr>".
word_math_font_ctrl --> "<m:ctrlPr>", word_math_font, "</m:ctrlPr>".

word_modifiers(Modifiers) -->
	"<m:rPr><m:sty m:val=\"",
	( { memberchk(plain, Modifiers) } -> "p" ; [] ),
	( { memberchk(bold, Modifiers) } -> "b" ; [] ),
	( { memberchk(italic, Modifiers) } -> "i" ; [] ),
	"\"/>",
	( { memberchk(blackboard, Modifiers) } -> "<m:scr m:val=\"double-struck\"/>"
	; { memberchk(calligraphic, Modifiers) } -> "<m:scr m:val=\"script\"/>"
	; { memberchk(fraktur, Modifiers) } -> "<m:scr m:val=\"fraktur\"/>"
	; []
	),
	"</m:rPr>".

%
% Utility predicates
%

%% read_stream_string(+Stream, -String:list) is det.
% Reads an entire stream into a string.
read_stream_string(Stream, String) :-
	at_end_of_stream(Stream), !, String = [].
read_stream_string(Stream, String) :-
	read_pending_input(Stream, String, T),
	read_stream_string(Stream, T).

%% make_directory_recursive(+Directory:atom) is semidet.
% Creates a directory hierarchy, creating parent directories as needed.
make_directory_recursive(Directory) :-
	exists_directory(Directory), !.
make_directory_recursive(Directory) :-
	file_directory_name(Directory, Parent),
	make_directory_recursive(Parent),
	make_directory(Directory).

create_file(Filepath, Stream) :-
	file_directory_name(Filepath, Directory),
	make_directory_recursive(Directory),
	open(Filepath, write, Stream, [encoding(utf8)]).

%% line_column_position(+String:string, -Line:integer, -Column:integer) is det.
% When String is typeset, the number of lines is Line and the last line ends in index position Column.
line_column_position(String, Line, Column) :-
	findall(Before, sub_string(String, Before, 1, _After, '\n'), Occurrences),
	( last(Occurrences, Position), ! ; Position = -1 ),
	string_length(String, StringLength),
	length(Occurrences, LineCount),
	Line is LineCount + 1,
	Column is StringLength - Position.

%% transpose(+Ms, +Ts) is semidet.
%% transpose(+Ms, -Ts) is det.
% Ts is the transpose of the matrix Ms represented as a list of lists.
transpose(Ms, Ts) :- Ms = [F|_], transpose(F, Ms, Ts).

transpose([], _, []).
transpose([_|Rs], Ms, [Ts|Tss]) :-
	lists_firsts_rests(Ms, Ts, Ms1),
	transpose(Rs, Ms1, Tss).

lists_firsts_rests([], [], []).
lists_firsts_rests([[F|Os]|Rest], [F|Fs], [Os|Oss]) :-
	lists_firsts_rests(Rest, Fs, Oss).

%% term_hash_codes(+Term, -HashCodes) is det.
% HashCodes are the character codes of the hash value of Term.
term_hash_codes(Term, HashCodes) :-
	term_hash(Term, HashKey),
	atom_codes(HashKey, HashCodes).

any_codes(Any) --> { string_to_list(Any, Codes) }, Codes.

%% pretty_print(+Stream, +Term) is det.
% Pretty prints Term to Stream.
pretty_print(Stream, Term) :-
	phrase(pretty_term(Term), Codes),
	format(Stream, '~s', [Codes]).
pretty_print(Term) :-
	pretty_print(user_output, Term).

pretty_term(Term) --> pretty_term(Term, 0), ".".

pretty_term(Term, Indent) -->
	pretty_tabs(Indent),
	( { atom(Term) }                             -> pretty_atom(Term)
	; { string(Term) }                           -> pretty_string(Term)
	; { string_codes(String, Term) }             -> pretty_string(String)
	; { is_list(Term) }                          -> pretty_list(Term, Indent)
	; { functor(Term, Functor, _Arity) }         -> pretty_atom(Functor), "(\n", pretty_term_args(Term, Indent), pretty_tabs(Indent), ")"
	; { format(codes(Codes), '~w~n', [Term]) }, Codes
	).

pretty_terms([Head,Next|Tail], Indent) --> !,
	pretty_term(Head, Indent), ",\n",
	pretty_terms([Next|Tail], Indent).
pretty_terms([Head], Indent) --> !,
	pretty_term(Head, Indent), "\n".
pretty_terms([], _Indent) --> [].

pretty_term_args(Term, Indent) --> { Indent1 is Indent + 1, Term =.. [_|Args] }, pretty_terms(Args, Indent1).

pretty_tabs(0) --> !.
pretty_tabs(Count) --> { Count1 is Count - 1 }, "\t", pretty_tabs(Count1).

pretty_atom(Atom) --> { with_output_to(codes(Codes), write_canonical(Atom)) }, Codes.

pretty_string(String) --> { with_output_to(codes(Codes), write_term(String, [quoted(true),backquoted_string(true)])) }, Codes.

pretty_list(List, Indent) --> "[\n", { Indent1 is Indent + 1 }, pretty_terms(List, Indent1), pretty_tabs(Indent), "]".

%% is_code_list(Term) is semidet.
% Term is a list of character codes.
is_code_list(Term) :-
	is_list(Term),
	catch(string_to_list(Term, _String), _Exception, fail).

string_codes(String, Codes) :-
	catch(string_to_list(String, Codes), _Exception, fail),
	Codes = [Head|_Tail], integer(Head).  % exclude list of single character atoms
