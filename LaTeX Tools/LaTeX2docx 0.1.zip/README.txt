LaTeX2docx - A modified version of TeXsword
-------------------------------------------

Installation
------------
To use LaTeX2docx you have to install

-MiKTeX
-Ghostscript
-ImageMagick
-teX4ht

We recommend to read the detailed installation guide in the 
Documentation.pdf, Chapter 3 (Installation)


Authors
-------
Alexander Beljawski
Jordanis Andreanidis
Oliver Kopp